# Receipt Scanner Frontend

React app for uploading and scanning receipts using OCR.

## Setup

```bash
npm install
npm start
```