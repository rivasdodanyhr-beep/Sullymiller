import React, { useState } from 'react';
import ReceiptUpload from './components/ReceiptUpload';

function App() {
  const [result, setResult] = useState(null);

  return (
    <div>
      <h1>Receipt Scanner</h1>
      <ReceiptUpload setResult={setResult} />
      {result && (
        <div>
          <h2>Extracted Info</h2>
          <pre>{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default App;