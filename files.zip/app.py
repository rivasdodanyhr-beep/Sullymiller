from flask import Flask, request, jsonify
import cv2
import pytesseract
import numpy as np
from PIL import Image
import io

app = Flask(__name__)

def preprocess_image(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
    img_np = np.array(img)
    gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
    blur = cv2.GaussianBlur(gray, (3,3), 0)
    thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    return thresh

def parse_receipt_text(text):
    # Simple parsing logic (customize for your receipt format)
    lines = text.split('\n')
    vendor = lines[0] if lines else ""
    date = ""
    total = ""
    for line in lines:
        if "date" in line.lower():
            date = line
        if "total" in line.lower():
            total = line
    return {
        "vendor": vendor,
        "date": date,
        "total": total,
        "raw_text": text
    }

@app.route('/upload', methods=['POST'])
def upload_receipt():
    file = request.files['receipt']
    image_bytes = file.read()
    processed = preprocess_image(image_bytes)
    text = pytesseract.image_to_string(processed)
    info = parse_receipt_text(text)
    return jsonify(info)

if __name__ == '__main__':
    app.run(debug=True)